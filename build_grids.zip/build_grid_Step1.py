#----------------------------------------------------------------------#
# Title: Lesson 2 exercise for Python 210 Classes
# Dev: JPatten
# Date October 10, 2019
# ChangeLog: (When, Who, What)
# Purpose:  This program demonstrates how create a basic grid
#
#----------------------------------------------------------------------#
# -*- coding: utf-8 -*-

print("+","- "*4,"+","- "*4,"+")
print("|"," "*8,"|"," "*8,"|")
print("|"," "*8,"|"," "*8,"|")
print("|"," "*8,"|"," "*8,"|")
print("|"," "*8,"|"," "*8,"|")
print("+","- "*4,"+","- "*4,"+")
print("|"," "*8,"|"," "*8,"|")
print("|"," "*8,"|"," "*8,"|")
print("|"," "*8,"|"," "*8,"|")
print("|"," "*8,"|"," "*8,"|")
print("+","- "*4,"+","- "*4,"+")
